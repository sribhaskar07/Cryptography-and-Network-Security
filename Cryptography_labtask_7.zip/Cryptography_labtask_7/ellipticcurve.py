from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os

def derive_aes_key(shared_secret):
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b'aes key',
    )
    return hkdf.derive(shared_secret)

def encrypt_message(key, message):
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(message.encode()) + encryptor.finalize()
    return iv, ciphertext, encryptor.tag

def decrypt_message(key, iv, ciphertext, tag):
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()
    return decryptor.update(ciphertext) + decryptor.finalize()

def perform_key_exchange_and_encryption(curve):
    private_key_alice = ec.generate_private_key(curve)
    private_key_bob = ec.generate_private_key(curve)
    public_key_alice = private_key_alice.public_key()
    public_key_bob = private_key_bob.public_key()
    shared_key_alice = private_key_alice.exchange(ec.ECDH(), public_key_bob)
    shared_key_bob = private_key_bob.exchange(ec.ECDH(), public_key_alice)
    aes_key_alice = derive_aes_key(shared_key_alice)
    aes_key_bob = derive_aes_key(shared_key_bob)
    assert aes_key_alice == aes_key_bob, "AES keys do not match!"
    message = "Hell0 SRM AP"
    iv, ciphertext, tag = encrypt_message(aes_key_alice, message)
    decrypted_message = decrypt_message(aes_key_bob, iv, ciphertext, tag)
    assert decrypted_message.decode() == message, "Decryption failed!"
    print(f"Curve: {curve.name}")
    print(f"Original Message: {message}")
    print(f"Encrypted Message: {ciphertext.hex()}")
    print(f"Decrypted Message: {decrypted_message.decode()}")
    print()

print("Using SECP256R1 Curve:")
perform_key_exchange_and_encryption(ec.SECP256R1())

print("Using SECP384R1 Curve:")
perform_key_exchange_and_encryption(ec.SECP384R1())