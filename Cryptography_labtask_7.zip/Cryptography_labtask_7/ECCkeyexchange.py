from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes

private_key_alice = ec.generate_private_key(ec.SECP256R1())
private_key_bob = ec.generate_private_key(ec.SECP256R1())

public_key_alice = private_key_alice.public_key()
public_key_bob = private_key_bob.public_key()

shared_key_alice = private_key_alice.exchange(ec.ECDH(), public_key_bob)
shared_key_bob = private_key_bob.exchange(ec.ECDH(), public_key_alice)

def derive_symmetric_key(shared_secret):
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b'handshake data',
    )
    return hkdf.derive(shared_secret)

symmetric_key_alice = derive_symmetric_key(shared_key_alice)
symmetric_key_bob = derive_symmetric_key(shared_key_bob)

assert symmetric_key_alice == symmetric_key_bob, "Symmetric keys do not match!"

print("Key exchange successful!")
print("Symmetric Key (Alice):", symmetric_key_alice.hex())
print("Symmetric Key (Bob):", symmetric_key_bob.hex())