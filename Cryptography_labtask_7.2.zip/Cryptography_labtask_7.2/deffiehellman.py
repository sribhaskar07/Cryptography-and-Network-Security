import hashlib
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

# Diffie-Hellman Key Exchange (Simulated)
def diffie_hellman_key_exchange():
    private_key = os.urandom(16)  # Simulated private key
    shared_secret = hashlib.sha256(private_key).digest()[:16]  # Derived AES key
    return shared_secret

# Compute Hash of Message
def compute_hash(message):
    return hashlib.sha256(message.encode()).hexdigest()

# Encrypt Message + Hash using AES
def encrypt_message(message, key):
    iv = get_random_bytes(16)  
    cipher = AES.new(key, AES.MODE_CBC, iv)
    hash_code = compute_hash(message)
    combined_data = message + hash_code
    encrypted_data = cipher.encrypt(pad(combined_data.encode(), AES.block_size))
    return iv + encrypted_data  # Send IV with encrypted data

# Decrypt and Verify Integrity
def decrypt_message(encrypted_data, key):
    iv, encrypted_msg = encrypted_data[:16], encrypted_data[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_data = unpad(cipher.decrypt(encrypted_msg), AES.block_size).decode()
    
    received_message, received_hash = decrypted_data[:-64], decrypted_data[-64:]
    
    if compute_hash(received_message) == received_hash:
        print("Integrity Check Passed ✅")
    else:
        print("Integrity Check Failed ❌")
    
    return received_message

# Simulate Secure Message Transmission
session_key = diffie_hellman_key_exchange()
message = input("Enter Message: ")
encrypted_message = encrypt_message(message, session_key)
decrypted_message = decrypt_message(encrypted_message, session_key)

print(f"Decrypted Message: {decrypted_message}")
