import hashlib

def generate_sha512_hash(text):
    encoded_text = text.encode('utf-8')
    sha512_hash = hashlib.sha512(encoded_text)
    return sha512_hash.hexdigest()

text = input("Enter text to hash: ")
hash_result = generate_sha512_hash(text)
print(f"SHA-512 Hash: {hash_result}")
