import socket
from Crypto.Cipher import ARC4

def rc4_encrypt(data, key):
cipher = ARC4.new(key) 
 return cipher.encrypt(data)

def client():
host = 'localhost'
port = 12345
key = b'secretkey'  
file_name = 'RC4.txt' 
encrypted_file = 'file_encrypted.txt'  

with open(file_name, 'rb') as f:  
data = f.read()
    

encrypted_data = rc4_encrypt(data, key)
    

with open(encrypted_file, 'wb') as f:
f.write(encrypted_data)
    

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((host, port))
    
  
client_socket.send(encrypted_data)
print("Encrypted file sent.")


client_socket.close()

if __name__ == "__main__":
client()
