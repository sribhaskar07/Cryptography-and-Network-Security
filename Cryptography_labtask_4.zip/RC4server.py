import socket
from Crypto.Cipher import ARC4

def rc4_decrypt(data, key):
cipher = ARC4.new(key)
return cipher.decrypt(data)

def server():
host = 'localhost'
port = 12345
key = b'secretkey'  
encrypted_file = 'recieved_encrypted.txt'
decrypted_file = 'decrypted.txt'

 
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((host, port))
server_socket.listen(1)
    
print("Server is listening...")
conn, addr = server_socket.accept()
print("Connection from", addr)
    
encrypted_data = conn.recv(4096)
    
with open(encrypted_file, 'wb') as f:
f.write(encrypted_data)
    
decrypted_data = rc4_decrypt(encrypted_data, key)
    
with open(decrypted_file, 'wb') as f:
f.write(decrypted_data)
    
print("Files saved: Encrypted and Decrypted.")
    
conn.close()
server_socket.close()

if __name__ == "__main__":
server()
