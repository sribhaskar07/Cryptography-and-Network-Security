import random

def generate_prime():
    while True:
        num = random.randint(100, 1000)
        if is_prime(num):
            return num

def is_prime(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def mod_power(base, exponent, modulus):
    result = 1
    while exponent > 0:
        if exponent % 2 == 1:
            result = (result * base) % modulus
        exponent //= 2
        base = (base * base) % modulus
    return result

class DiffieHellman:
    def __init__(self, prime=None, generator=None):
        if prime is None:
            self.prime = generate_prime()
        else:
            self.prime = prime
        if generator is None:
            self.generator = self.find_generator()
        else:
            self.generator = generator
        self.private_key = random.randint(1, self.prime - 1)
        self.public_key = mod_power(self.generator, self.private_key, self.prime)

    def find_generator(self):
        for g in range(2, self.prime):
            if self.is_generator(g):
                return g

    def is_generator(self, g):
        seen = set()
        for i in range(1, self.prime):
            x = mod_power(g, i, self.prime)
            if x in seen:
                return False
            seen.add(x)
        return True

    def compute_shared_secret(self, other_public_key):
        return mod_power(other_public_key, self.private_key, self.prime)

# Example usage
alice = DiffieHellman()
bob = DiffieHellman(alice.prime, alice.generator)

print("Diffie-Hellman Key Exchange")
print("---------------------------")
print(f"Alice's prime: {alice.prime}")
print(f"Alice's generator: {alice.generator}")
print(f"Alice's private key: {alice.private_key}")
print(f"Alice's public key: {alice.public_key}")

print("\nBob's Details:")
print(f"Bob's prime: {bob.prime}")
print(f"Bob's generator: {bob.generator}")
print(f"Bob's private key: {bob.private_key}")
print(f"Bob's public key: {bob.public_key}")

print("\nKey Exchange:")
print(f"Alice sends her public key to Bob: {alice.public_key}")
print(f"Bob sends his public key to Alice: {bob.public_key}")

alice_shared_secret = alice.compute_shared_secret(bob.public_key)
bob_shared_secret = bob.compute_shared_secret(alice.public_key)

print("\nShared Secrets:")
print(f"Alice's shared secret: {alice_shared_secret}")
print(f"Bob's shared secret: {bob_shared_secret}")

if alice_shared_secret == bob_shared_secret:
    print("Shared secrets match. Key exchange successful!")
else:
    print("Shared secrets do not match. Key exchange failed.")
