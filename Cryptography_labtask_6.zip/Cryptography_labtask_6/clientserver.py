import socket
import threading
import random
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os
import json
import base64

# Diffie-Hellman functions
def generate_large_prime(bits=512):
    """Generate a prime number with the specified number of bits"""
    # For demonstration, we'll use a known prime
    # In production, use a cryptographically secure method to generate primes
    return 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF

def encrypt_message(key, message):
    """Encrypt a message using AES-GCM"""
    # Convert key to 32 bytes (256 bits) using SHA-256
    key_bytes = hashlib.sha256(str(key).encode()).digest()
    
    # Generate a random 12-byte nonce
    nonce = os.urandom(12)
    
    # Create an encryptor object
    cipher = Cipher(
        algorithms.AES(key_bytes),
        modes.GCM(nonce),
        backend=default_backend()
    )
    encryptor = cipher.encryptor()
    
    # Encrypt the message
    ciphertext = encryptor.update(message.encode()) + encryptor.finalize()
    
    # Get the authentication tag
    tag = encryptor.tag
    
    # Return base64-encoded nonce, ciphertext, and tag
    encrypted_data = {
        'nonce': base64.b64encode(nonce).decode('utf-8'),
        'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
        'tag': base64.b64encode(tag).decode('utf-8')
    }
    
    return json.dumps(encrypted_data)

def decrypt_message(key, encrypted_data_json):
    """Decrypt a message using AES-GCM"""
    # Parse the JSON data
    encrypted_data = json.loads(encrypted_data_json)
    
    # Decode the base64 components
    nonce = base64.b64decode(encrypted_data['nonce'])
    ciphertext = base64.b64decode(encrypted_data['ciphertext'])
    tag = base64.b64decode(encrypted_data['tag'])
    
    # Convert key to 32 bytes using SHA-256
    key_bytes = hashlib.sha256(str(key).encode()).digest()
    
    # Create a decryptor object
    cipher = Cipher(
        algorithms.AES(key_bytes),
        modes.GCM(nonce, tag),
        backend=default_backend()
    )
    decryptor = cipher.decryptor()
    
    # Decrypt the message
    decrypted_message = decryptor.update(ciphertext) + decryptor.finalize()
    
    return decrypted_message.decode('utf-8')

class Server:
    def __init__(self, host='localhost', port=5555):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.clients = {}
        
        # Diffie-Hellman parameters
        self.p = generate_large_prime()
        self.g = 2  # Using 2 as the generator
        self.private_key = random.randint(2, self.p - 2)
        self.public_key = pow(self.g, self.private_key, self.p)
        
    def start(self):
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        print(f"Server started on {self.host}:{self.port}")
        print(f"Diffie-Hellman parameters - p: {self.p}, g: {self.g}")
        print(f"Server's public key: {self.public_key}")
        
        while True:
            client_socket, address = self.server_socket.accept()
            print(f"Connection established with {address}")
            
            # Start a new thread to handle the client
            client_thread = threading.Thread(target=self.handle_client, args=(client_socket, address))
            client_thread.daemon = True
            client_thread.start()
            
    def handle_client(self, client_socket, address):
        try:
            # Send Diffie-Hellman parameters to the client
            client_socket.send(f"{self.p},{self.g},{self.public_key}".encode())
            
            # Receive client's public key
            client_public_key = int(client_socket.recv(4096).decode())
            print(f"Received client public key: {client_public_key}")
            
            # Compute the shared secret
            shared_secret = pow(client_public_key, self.private_key, self.p)
            print(f"Computed shared secret: {shared_secret}")
            
            # Store the client and its shared secret
            self.clients[client_socket] = shared_secret
            
            # Handle messages from the client
            while True:
                encrypted_message = client_socket.recv(4096).decode()
                if not encrypted_message:
                    break
                
                # Decrypt the message
                decrypted_message = decrypt_message(shared_secret, encrypted_message)
                print(f"Decrypted message from client: {decrypted_message}")
                
                # Echo back the message (encrypted)
                response = f"Server received: {decrypted_message}"
                encrypted_response = encrypt_message(shared_secret, response)
                client_socket.send(encrypted_response.encode())
                
        except Exception as e:
            print(f"Error handling client {address}: {e}")
        finally:
            if client_socket in self.clients:
                del self.clients[client_socket]
            client_socket.close()
            print(f"Connection with {address} closed")

class Client:
    def __init__(self, host='localhost', port=5555):
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # Diffie-Hellman parameters (to be received from server)
        self.p = None
        self.g = None
        self.private_key = None
        self.public_key = None
        self.shared_secret = None
        
    def connect(self):
        try:
            self.client_socket.connect((self.host, self.port))
            
            # Receive Diffie-Hellman parameters from the server
            dh_params = self.client_socket.recv(4096).decode().split(',')
            self.p = int(dh_params[0])
            self.g =