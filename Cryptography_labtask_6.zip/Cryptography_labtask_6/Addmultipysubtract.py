# Python natively handles big integers, so no special library is needed
a = 182841384165841685416854134135
b = 135481653441354138548413384135

# Addition
addition_result = a + b
print(f"Addition: {addition_result}")

# Subtraction
subtraction_result = a - b
print(f"Subtraction: {subtraction_result}")

# Multiplication
multiplication_result = a * b
print(f"Multiplication: {multiplication_result}")

# Division (returns float in Python 2, but returns int in Python 3 when using //)
division_result = a // b
remainder = a % b
print(f"Division (quotient): {division_result}")
print(f"Division (remainder): {remainder}")

# Floating point division
float_division_result = a / b
print(f"Float Division: {float_division_result}")