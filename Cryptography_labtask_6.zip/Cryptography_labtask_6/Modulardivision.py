def extended_gcd(a, b):
    """
    Extended Euclidean Algorithm to find gcd(a,b) and coefficients x,y such that ax + by = gcd(a,b)
    """
    if a == 0:
        return b, 0, 1
    else:
        gcd, x1, y1 = extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y

def mod_inverse(a, m):
    """
    Calculates the modular multiplicative inverse of a modulo m
    """
    gcd, x, y = extended_gcd(a, m)
    if gcd != 1:
        raise Exception('Modular inverse does not exist')
    else:
        return x % m

def mod_divide(a, b, m):
    """
    Calculates a/b mod m
    Equivalent to a * (b^-1) mod m where b^-1 is the modular multiplicative inverse of b
    """
    b_inv = mod_inverse(b, m)
    return (a * b_inv) % m

# Example with our large numbers
a = 182841384165841685416854134135
b = 135481653441354138548413384135

# Choose a modulus (for example, a prime number)
modulus = 1000000007  # A commonly used prime modulus

result = mod_divide(a, b, modulus)
print(f"Result of {a} / {b} mod {modulus} = {result}")

# Alternative verification using the relationship: (a/b) mod m = (a mod m) * (b^-1 mod m) mod m
b_inverse = mod_inverse(b % modulus, modulus)
verification = ((a % modulus) * b_inverse) % modulus
print(f"Verification: {verification}")