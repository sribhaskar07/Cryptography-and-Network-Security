import random

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def multiplicative_inverse(e, phi):
    d = 0
    x1 = 0
    x2 = 1
    phi_temp = phi
    while e > 0:
        q = phi_temp // e
        r = phi_temp % e
        phi_temp = e
        e = r
        x = x2 - q * x1
        x2 = x1
        x1 = x
    if phi_temp == 1:
        d = x2 + phi
    return d

def is_prime(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def generate_keypair(p, q):
    if not (is_prime(p) and is_prime(q)):
        raise ValueError('Both numbers must be prime.')
    elif p == q:
        raise ValueError('p and q cannot be equal')
    n = p * q
    phi = (p-1) * (q-1)
    e = random.randrange(1, phi)
    g = gcd(e, phi)
    while g != 1:
        e = random.randrange(1, phi)
        g = gcd(e, phi)
    d = multiplicative_inverse(e, phi)
    return ((e, n), (d, n))

def encrypt(public_key, plaintext):
    e, n = public_key
    cipher_text = [pow(ord(char), e, n) for char in plaintext]
    return cipher_text

def decrypt(private_key, cipher_text):
    d, n = private_key
    plain_text = ''.join([chr(pow(char, d, n)) for char in cipher_text])
    return plain_text

if __name__ == '__main__':
    p = int(input("Enter a prime number (p): "))
    q = int(input("Enter another prime number (q): "))
    public_key, private_key = generate_keypair(p, q)
    
    user_input = input("Enter text to encrypt: ")
    encrypted_text = encrypt(public_key, user_input)
    decrypted_text = decrypt(private_key, encrypted_text)
    
    print("\nPublic key:", public_key)
    print("Private key:", private_key)
    print("\nOriginal Input:", user_input)
    print("Encrypted Text:", encrypted_text)
    print("Decrypted Text:", decrypted_text)
